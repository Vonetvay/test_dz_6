using UnityEngine;
using UnityEngine.UI;

public class BallMerging : Merging
{
    [SerializeField] private GameObject _affectedAreaSprite;
    private Animator _affectedAreaSpriteAnimator;
    private Image _affectedAreaSpriteImage;

    private bool _iMainBall;

    private float _bogieYPosition;

    private BallLevel _ballLevel;
    private DisplayBallLevel _displayBallLevel;
    private MeshRenderer _meshRenderer;
    [SerializeField] private Collider _collider;

    private void Awake()
    {
        _meshRenderer = GetComponent<MeshRenderer>();
        _ballLevel = GetComponent<BallLevel>();
        _displayBallLevel = GetComponent<DisplayBallLevel>();

        _affectedAreaSpriteAnimator = _affectedAreaSprite.GetComponent<Animator>();
        _affectedAreaSpriteImage = _affectedAreaSprite.GetComponent<Image>();
    }

    private void Start() 
    {
        _bogieYPosition = FindObjectOfType<BogieMovement>().transform.position.y;
    }

    public bool GetMain() => _iMainBall;

    private void OnTriggerEnter(Collider collision)
    {
        if (transform.position.y < _bogieYPosition + 2f) 
        {
            if (collision.gameObject.GetComponent<Dynamite>() is Dynamite _dynamite) 
            {
                if (_ballLevel.level == _dynamite.GetLevel()) 
                {
                    _dynamite.Activate();
                    Destroy(gameObject);
                }
            }
            else if (collision.gameObject.GetComponent<BallLevel>() is BallLevel _collisionBallMerging)
            {
                if (_ballLevel.level == _collisionBallMerging.level)
                {
                    if (transform.position.y < collision.transform.position.y) { _iMainBall = true; }
                    if (_iMainBall)
                    {
                        Destroy(collision.gameObject);
                        _ballLevel.AddLevel();
                        _displayBallLevel.Display();
                        _collider.enabled = false;
                        _collider.enabled = true;
                        BreakObjects();
                        _affectedAreaSprite.SetActive(true);
                        _affectedAreaSpriteImage.color = _meshRenderer.material.color;
                        Invoke("HideAffectedAreaSprite", .2f);
                        _affectedAreaSpriteAnimator.SetTrigger("Extension");
                    }
                }
            }
        }
    }

    public void HideAffectedAreaSprite() 
    {
        _affectedAreaSprite.SetActive(false);
    }
}
