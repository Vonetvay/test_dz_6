using UnityEngine;

public class BogieRayCasting : MonoBehaviour
{
    private BogieBallContainer _bogieBallContainer;
    private GameObject _copyBall;

    [SerializeField] private GameObject _tube;
    [SerializeField] private float _tubeWidth;

    [SerializeField] private float _radius = .5f;
    [SerializeField] private float _offset = 0f;
    [SerializeField] private float _copyBallAlpha = .5f;

    private float _yAxisPosition;

    private void Awake()
    {
        _bogieBallContainer = GetComponent<BogieBallContainer>();
        _yAxisPosition = transform.position.y;
    }

    public float GetYAxis() => _yAxisPosition;

    private void Update()
    {
        if (_bogieBallContainer.ball != null) 
        {
            if (_copyBall == null) 
            {
                _tube.SetActive(true);

                _copyBall = Instantiate(_bogieBallContainer.ball, transform.position, Quaternion.identity);

                Color _color = _copyBall.GetComponent<MeshRenderer>().material.color;
                _color.a = _copyBallAlpha;
                _copyBall.GetComponent<MeshRenderer>().material.color = _color;

                foreach (var c in _copyBall.GetComponents<Collider>()) 
                {
                    c.enabled = false;
                }
                
            }
            Ray _ray = new Ray(transform.position, Vector3.down);
            RaycastHit _hit;
            if (Physics.SphereCast(_ray, _radius, out _hit)) 
            {
                _copyBall.transform.position = new Vector3(transform.position.x, _offset + _yAxisPosition - _hit.distance, transform.position.z);
                _tube.transform.localScale = new Vector3(_tubeWidth, _hit.distance / 2f, 1f);
                _tube.transform.position = new Vector3(transform.position.x,
                                                       _hit.distance / 2f + _yAxisPosition - _hit.distance + _offset,
                                                       transform.position.z);
            }
        }
        else if (_copyBall != null)
        {
            _tube.SetActive(false);
            Destroy(_copyBall);
            _copyBall = null;
        }
    }
}
