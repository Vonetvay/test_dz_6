using UnityEngine;

public class BreakableObject : MonoBehaviour
{
    [SerializeField] protected GameObject _breakParticles;

    public virtual void Break() 
    {
        GameObject _particles = Instantiate(_breakParticles, transform.position, Quaternion.identity);
        _particles.transform.localScale = transform.localScale;
        Destroy(gameObject);
    }
}
