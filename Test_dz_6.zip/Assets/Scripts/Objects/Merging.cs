using UnityEngine;

public class Merging : MonoBehaviour
{
    [SerializeField] private float _afterMergeAreaRadius;
    [SerializeField] private LayerMask _afterMergeAreaLayer;

    public void BreakObjects() 
    {
        foreach (var obj in Physics.OverlapSphere(transform.position, _afterMergeAreaRadius, _afterMergeAreaLayer))
        {
            BreakableObject _objBreakableObject = obj.gameObject.GetComponent<BreakableObject>();
            if (_objBreakableObject != null)
            {
                _objBreakableObject.Break();
            }
        }
    }
}
