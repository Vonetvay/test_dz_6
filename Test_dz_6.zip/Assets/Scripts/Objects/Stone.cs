using UnityEngine;

public class Stone : BreakableObject
{
    [SerializeField] private float _maxBreaks;
    [HideInInspector] public float currentBreaks;

    public override void Break()
    {
        if (currentBreaks < _maxBreaks) 
        {
            GameObject _copy = gameObject;
            Vector3 _scale = gameObject.transform.localScale;
            _copy.transform.localScale = _scale * .5f;
            _copy.GetComponent<Stone>().currentBreaks = currentBreaks + 1;
            Instantiate(_copy, transform.position + new Vector3(_scale.x * .25f, 0f, 0f), Quaternion.identity);
            Instantiate(_copy, transform.position - new Vector3(_scale.x * .25f, 0f, 0f), Quaternion.identity);
        }
        base.Break();
    }
}
