using UnityEngine;

public class Dynamite : Merging
{
    [SerializeField] private Animator _affectedAreaSpriteAnimator;

    [SerializeField] private float _timeToExplosion;

    [SerializeField] private float _level;

    public float GetLevel() => _level;

    public void Activate() 
    {
        Invoke("Explosion", _timeToExplosion);
        _affectedAreaSpriteAnimator.SetTrigger("Show");
    }

    private void Explosion() 
    {
        BreakObjects();
        Destroy(gameObject);
    }
}
